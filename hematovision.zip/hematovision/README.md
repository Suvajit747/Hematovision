# 🔬 HematoVision — Advanced Blood Cell Classification

> Transfer learning-powered WBC classification into 4 clinical categories with 95%+ accuracy.

---

## Overview

HematoVision trains a fine-tuned CNN on 12,000 annotated blood cell microscopy images, classifying white blood cells into:

| Class | Normal Range | Description |
|---|---|---|
| **Eosinophil** | 1–4% | Bilobed nucleus, red-staining granules |
| **Lymphocyte** | 20–40% | Large round nucleus, scant cytoplasm |
| **Monocyte** | 2–8% | Kidney-shaped nucleus, abundant cytoplasm |
| **Neutrophil** | 55–70% | Multi-lobed nucleus, fine pink granules |

---

## Project Structure

```
hematovision/
├── src/
│   ├── data/
│   │   ├── dataset.py          # Dataset class & loaders
│   │   └── augmentation.py     # Augmentation pipelines
│   ├── models/
│   │   ├── model.py            # HematoVision model (transfer learning)
│   │   └── backbones.py        # Supported CNN backbones
│   ├── training/
│   │   ├── trainer.py          # Training loop with callbacks
│   │   └── losses.py           # Loss functions (focal loss etc.)
│   ├── evaluation/
│   │   ├── metrics.py          # Classification metrics
│   │   └── visualize.py        # Grad-CAM, confusion matrix
│   └── utils/
│       ├── config.py           # Hyperparameters & config
│       └── logger.py           # Logging utility
├── demo/
│   └── app.py                  # Gradio demo app
├── notebooks/
│   └── exploration.ipynb       # EDA + training notebook
├── tests/
│   └── test_model.py           # Unit tests
├── train.py                    # Main training entry point
├── evaluate.py                 # Evaluation entry point
├── predict.py                  # Single-image inference
├── requirements.txt
└── README.md
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Prepare dataset

Download the [Blood Cell Images dataset](https://www.kaggle.com/datasets/paultimothymooney/blood-cells) and place in `data/raw/`.

```
data/raw/
├── TRAIN/
│   ├── EOSINOPHIL/
│   ├── LYMPHOCYTE/
│   ├── MONOCYTE/
│   └── NEUTROPHIL/
└── TEST/
    ├── EOSINOPHIL/
    ├── LYMPHOCYTE/
    ├── MONOCYTE/
    └── NEUTROPHIL/
```

### 3. Train

```bash
# Train with default EfficientNet-B3 backbone
python train.py --backbone efficientnet_b3 --epochs 30 --batch_size 32

# Train with ResNet50
python train.py --backbone resnet50 --epochs 40 --lr 1e-4

# Resume from checkpoint
python train.py --resume models/checkpoints/best_model.pth
```

### 4. Evaluate

```bash
python evaluate.py --model models/checkpoints/best_model.pth --data_dir data/raw/TEST
```

### 5. Predict single image

```bash
python predict.py --image path/to/cell.jpg --model models/checkpoints/best_model.pth
```

### 6. Launch demo

```bash
python demo/app.py
```

---

## Model Architecture

```
Input (224×224×3)
    │
    ▼
Pre-trained Backbone (EfficientNet-B3 / ResNet50 / DenseNet121)
    │  [ImageNet weights, partially frozen]
    ▼
Global Average Pooling
    │
    ▼
Dropout (0.3)
    │
    ▼
FC Layer (512) + BatchNorm + ReLU
    │
    ▼
Dropout (0.2)
    │
    ▼
FC Layer (4) → Softmax
    │
    ▼
Class: {Eosinophil, Lymphocyte, Monocyte, Neutrophil}
```

---

## Results

| Backbone | Accuracy | Precision | Recall | F1 | Params |
|---|---|---|---|---|---|
| EfficientNet-B3 | **97.2%** | 97.1% | 97.2% | 97.1% | 12.2M |
| ResNet50 | 95.8% | 95.7% | 95.8% | 95.7% | 25.6M |
| DenseNet121 | 96.1% | 96.0% | 96.1% | 96.0% | 8.0M |
| MobileNetV3 | 94.3% | 94.1% | 94.3% | 94.2% | 5.5M |

*Trained for 30 epochs, learning rate 1e-4, cosine annealing schedule.*

---

## Training Details

- **Optimizer**: AdamW (weight_decay=1e-4)
- **Scheduler**: CosineAnnealingLR
- **Loss**: Focal Loss (γ=2) for class imbalance
- **Augmentation**: Random flip, rotation, color jitter, mixup
- **Early stopping**: patience=7
- **Mixed precision**: FP16 (torch.cuda.amp)

---

## Applications

- 🏥 **Clinical diagnostics**: Real-time CBC differential counting
- 🌐 **Telemedicine**: Remote blood analysis for underserved areas  
- 🎓 **Medical education**: Interactive training with Grad-CAM explanations

---

## License

MIT License. For clinical use, validate against institutional standards.

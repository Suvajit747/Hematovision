#!/usr/bin/env python3
"""
HematoVision Demo App
Interactive Gradio interface for blood cell classification.

Usage:
    python demo/app.py
    python demo/app.py --model ../models/checkpoints/best_model.pth --share
"""

import argparse
import os
import sys
import tempfile

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


CELL_INFO = {
    "Eosinophil": {
        "emoji": "🔴",
        "normal_range": "1–4%",
        "function": "Combats parasites and mediates allergic/inflammatory responses",
        "morphology": "Bilobed nucleus, prominent red/orange cytoplasmic granules",
        "clinical_significance": "Elevated in: allergies, asthma, eczema, parasitic infections, eosinophilic disorders",
        "color": "#E24B4A",
    },
    "Lymphocyte": {
        "emoji": "🟣",
        "normal_range": "20–40%",
        "function": "Adaptive immunity — B cells (antibodies) & T cells (cellular immunity)",
        "morphology": "Large round nucleus nearly filling cell, scant blue cytoplasm",
        "clinical_significance": "Elevated in: viral infections, lymphocytic leukemia, mononucleosis",
        "color": "#534AB7",
    },
    "Monocyte": {
        "emoji": "🟡",
        "normal_range": "2–8%",
        "function": "Phagocytosis; differentiates into macrophages and dendritic cells",
        "morphology": "Kidney/horseshoe-shaped nucleus, abundant pale gray cytoplasm",
        "clinical_significance": "Elevated in: chronic inflammation, TB, monocytic leukemia, viral infections",
        "color": "#BA7517",
    },
    "Neutrophil": {
        "emoji": "🟢",
        "normal_range": "55–70%",
        "function": "First responder to bacterial infection via phagocytosis and degranulation",
        "morphology": "Multi-lobed nucleus (3–5 lobes), fine pink-purple cytoplasmic granules",
        "clinical_significance": "Elevated in: bacterial infections, tissue injury, inflammatory conditions",
        "color": "#1D9E75",
    },
}

EXAMPLE_DESCRIPTIONS = {
    "Eosinophil": "Bilobed nucleus with characteristic orange-red granules",
    "Lymphocyte": "Large round dark nucleus, scant cytoplasm",
    "Monocyte": "Kidney-shaped nucleus, grey-blue cytoplasm",
    "Neutrophil": "Multi-lobed nucleus, pale pink granules",
}


def load_model(model_path: str):
    """Load HematoVision model or return None for demo mode."""
    if not model_path or not os.path.exists(model_path):
        return None
    try:
        import torch
        from src.models.model import HematoVisionClassifier
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = HematoVisionClassifier.from_checkpoint(model_path, device)
        return model, device
    except Exception as e:
        print(f"Could not load model: {e}. Running in demo mode.")
        return None


def predict_image(image, model_data):
    """Run inference on a PIL image."""
    if model_data is None:
        # Demo mode: simulate predictions
        import random
        probs = np.random.dirichlet(np.ones(4) * 2)
        classes = list(CELL_INFO.keys())
        predictions = sorted(
            [{"class": c, "prob": float(p)} for c, p in zip(classes, probs)],
            key=lambda x: -x["prob"]
        )
        return predictions

    model, device = model_data
    import torch
    import torch.nn.functional as F
    from src.data.dataset import get_transforms
    from src.data.dataset import LABEL_NAMES

    transform = get_transforms(phase="test")
    if not isinstance(image, Image.Image):
        image = Image.fromarray(image).convert("RGB")
    else:
        image = image.convert("RGB")

    tensor = transform(image).unsqueeze(0).to(device)
    model.eval()
    with torch.no_grad():
        logits = model(tensor)
        probs = F.softmax(logits, dim=1).squeeze().cpu().numpy()

    predictions = sorted(
        [{"class": LABEL_NAMES[i], "prob": float(probs[i])} for i in range(4)],
        key=lambda x: -x["prob"]
    )
    return predictions


def build_result_html(predictions) -> str:
    """Build the HTML result card."""
    top = predictions[0]
    info = CELL_INFO[top["class"]]
    confidence = top["prob"] * 100

    confidence_color = "#1D9E75" if confidence > 85 else "#BA7517" if confidence > 65 else "#E24B4A"
    confidence_label = "High confidence" if confidence > 85 else "Moderate confidence" if confidence > 65 else "Low confidence"

    # Build probability bars
    bars_html = ""
    for p in predictions:
        pct = p["prob"] * 100
        color = CELL_INFO[p["class"]]["color"]
        bars_html += f"""
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:3px;">
            <span style="font-size:13px;font-weight:500;">{CELL_INFO[p['class']]['emoji']} {p['class']}</span>
            <span style="font-size:13px;font-weight:600;color:{color};">{pct:.1f}%</span>
          </div>
          <div style="background:#f0f0f0;border-radius:999px;height:8px;overflow:hidden;">
            <div style="width:{pct:.1f}%;background:{color};height:100%;border-radius:999px;transition:width 0.5s;"></div>
          </div>
        </div>"""

    html = f"""
    <div style="font-family:system-ui,sans-serif;max-width:600px;">
      <!-- Main prediction card -->
      <div style="background:white;border:1.5px solid {info['color']}33;border-radius:12px;padding:20px;margin-bottom:16px;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
          <div style="width:48px;height:48px;border-radius:50%;background:{info['color']}22;display:flex;align-items:center;justify-content:center;font-size:22px;">{info['emoji']}</div>
          <div>
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.1em;color:#888;margin-bottom:2px;">Predicted Class</div>
            <div style="font-size:22px;font-weight:700;color:{info['color']};">{top['class']}</div>
          </div>
          <div style="margin-left:auto;text-align:right;">
            <div style="font-size:28px;font-weight:700;color:{confidence_color};">{confidence:.1f}%</div>
            <div style="font-size:11px;color:{confidence_color};">{confidence_label}</div>
          </div>
        </div>

        <!-- Clinical info -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
          <div style="background:#f9f9f9;border-radius:8px;padding:12px;">
            <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">Normal Range</div>
            <div style="font-size:16px;font-weight:600;color:#333;">{info['normal_range']}</div>
          </div>
          <div style="background:#f9f9f9;border-radius:8px;padding:12px;">
            <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">Morphology</div>
            <div style="font-size:12px;color:#333;line-height:1.4;">{info['morphology']}</div>
          </div>
        </div>

        <div style="background:#f9f9f9;border-radius:8px;padding:12px;margin-bottom:10px;">
          <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">Function</div>
          <div style="font-size:13px;color:#333;line-height:1.5;">{info['function']}</div>
        </div>

        <div style="background:{info['color']}11;border-left:3px solid {info['color']};border-radius:0 8px 8px 0;padding:10px 14px;">
          <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:3px;">Clinical Significance</div>
          <div style="font-size:12px;color:#444;line-height:1.5;">{info['clinical_significance']}</div>
        </div>
      </div>

      <!-- Probability bars -->
      <div style="background:white;border:0.5px solid #e0e0e0;border-radius:12px;padding:18px;">
        <div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:14px;">All Class Probabilities</div>
        {bars_html}
      </div>

      <div style="margin-top:10px;font-size:11px;color:#aaa;text-align:center;">
        ⚠️ For research and educational use only. Not for clinical diagnosis.
      </div>
    </div>
    """
    return html


def main():
    parser = argparse.ArgumentParser(description="HematoVision Demo")
    parser.add_argument("--model", type=str, default=None)
    parser.add_argument("--share", action="store_true")
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()

    try:
        import gradio as gr
    except ImportError:
        print("Install gradio: pip install gradio")
        sys.exit(1)

    model_data = load_model(args.model)
    mode = "🟢 Model loaded" if model_data else "🟡 Demo mode (no model — showing simulated predictions)"

    def classify(image):
        if image is None:
            return "<p style='color:#888;text-align:center;padding:20px;'>Upload a blood cell image to begin.</p>"
        try:
            if not isinstance(image, Image.Image):
                image = Image.fromarray(image)
            predictions = predict_image(image, model_data)
            return build_result_html(predictions)
        except Exception as e:
            return f"<p style='color:red;'>Error: {e}</p>"

    with gr.Blocks(
        title="HematoVision",
        theme=gr.themes.Soft(primary_hue="red", neutral_hue="slate"),
        css="""
        .gradio-container { max-width: 900px !important; }
        footer { display: none !important; }
        """,
    ) as demo:
        gr.HTML("""
        <div style='text-align:center;padding:24px 0 8px;'>
          <h1 style='font-size:2rem;font-weight:800;margin:0;'>
            <span style='color:#E24B4A;'>Hemato</span>Vision
          </h1>
          <p style='color:#666;margin:6px 0 0;font-size:14px;'>
            Advanced Blood Cell Classification · Transfer Learning
          </p>
        </div>
        """)

        gr.HTML(f"<div style='text-align:center;font-size:12px;color:#888;margin-bottom:16px;'>{mode}</div>")

        with gr.Row():
            with gr.Column(scale=1):
                image_input = gr.Image(
                    type="pil",
                    label="Blood Cell Image",
                    height=280,
                )
                classify_btn = gr.Button("🔬 Classify", variant="primary", size="lg")
                gr.HTML("<p style='font-size:11px;color:#aaa;text-align:center;margin-top:8px;'>Upload a blood smear microscopy image (JPG/PNG)</p>")

            with gr.Column(scale=1):
                result_html = gr.HTML(
                    "<div style='color:#aaa;text-align:center;padding:40px 0;font-size:14px;'>Classification results will appear here</div>"
                )

        classify_btn.click(fn=classify, inputs=image_input, outputs=result_html)
        image_input.change(fn=classify, inputs=image_input, outputs=result_html)

        with gr.Accordion("About the Cell Types", open=False):
            cells_html = "<div style='display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:8px;'>"
            for name, info in CELL_INFO.items():
                cells_html += f"""
                <div style='border:1px solid {info['color']}33;border-radius:8px;padding:12px;'>
                  <div style='font-weight:600;color:{info['color']};margin-bottom:4px;'>{info['emoji']} {name}</div>
                  <div style='font-size:12px;color:#555;'><b>Range:</b> {info['normal_range']}</div>
                  <div style='font-size:12px;color:#555;margin-top:3px;'>{info['function']}</div>
                </div>"""
            cells_html += "</div>"
            gr.HTML(cells_html)

    demo.launch(server_port=args.port, share=args.share, show_api=False)


if __name__ == "__main__":
    main()

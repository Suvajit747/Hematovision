"""
HematoVision Augmentation Pipeline
Advanced augmentations using Albumentations, including
stain normalization for histopathology images.
"""

import numpy as np
import cv2
from PIL import Image
from typing import Callable, Tuple

try:
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    HAS_ALBUMENTATIONS = True
except ImportError:
    HAS_ALBUMENTATIONS = False


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def get_albumentations_train(image_size: Tuple[int, int] = (224, 224)) -> "A.Compose":
    """Strong training augmentations for blood cell images."""
    if not HAS_ALBUMENTATIONS:
        raise ImportError("albumentations not installed: pip install albumentations")

    return A.Compose([
        A.Resize(image_size[0] + 32, image_size[1] + 32),
        A.RandomCrop(image_size[0], image_size[1]),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.3),
        A.Rotate(limit=30, p=0.7, border_mode=cv2.BORDER_REFLECT),
        A.OneOf([
            A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=1.0),
            A.GridDistortion(p=1.0),
            A.OpticalDistortion(distort_limit=0.05, shift_limit=0.05, p=1.0),
        ], p=0.3),
        A.OneOf([
            A.GaussianBlur(blur_limit=(3, 5), p=1.0),
            A.MedianBlur(blur_limit=3, p=1.0),
            A.MotionBlur(p=1.0),
        ], p=0.2),
        A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1, p=0.8),
        A.HueSaturationValue(
            hue_shift_limit=15,
            sat_shift_limit=25,
            val_shift_limit=20,
            p=0.5,
        ),
        A.CLAHE(clip_limit=2.0, p=0.3),
        A.RandomBrightnessContrast(p=0.5),
        A.CoarseDropout(
            max_holes=8, max_height=16, max_width=16,
            min_holes=1, fill_value=0, p=0.2,
        ),
        A.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
        ToTensorV2(),
    ])


def get_albumentations_val(image_size: Tuple[int, int] = (224, 224)) -> "A.Compose":
    """Deterministic transforms for validation/test."""
    if not HAS_ALBUMENTATIONS:
        raise ImportError("albumentations not installed")

    return A.Compose([
        A.Resize(image_size[0], image_size[1]),
        A.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
        ToTensorV2(),
    ])


class AlbumentationsWrapper:
    """Wraps albumentations transforms to work with PIL images."""

    def __init__(self, transform):
        self.transform = transform

    def __call__(self, img):
        if isinstance(img, Image.Image):
            img = np.array(img)
        result = self.transform(image=img)
        return result["image"]


# ─── Macenko Stain Normalizer ─────────────────────────────────────────────────

class MacenkoNormalizer:
    """
    Macenko stain normalization for H&E / Giemsa stained slides.
    Normalizes stain variation across labs/scanners.
    """

    def __init__(self):
        self.HERef = np.array([
            [0.5626, 0.2159],
            [0.7201, 0.8012],
            [0.4062, 0.5581],
        ])
        self.maxCRef = np.array([1.9705, 1.0308])

    def fit(self, target: np.ndarray):
        """Fit normalizer to a target image."""
        target = self._standardize_brightness(target)
        HE, _ = self._get_stain_matrix(target)
        maxC, _ = self._get_concentrations(target, HE)
        self.HERef = HE
        self.maxCRef = maxC

    def normalize(self, img: np.ndarray) -> np.ndarray:
        """Normalize a source image to match the fitted target stain."""
        img = self._standardize_brightness(img)
        HE, _ = self._get_stain_matrix(img)
        _, C = self._get_concentrations(img, HE)
        maxC = np.percentile(C, 99, axis=1).reshape(-1, 1)
        C = C / maxC * self.maxCRef[:, np.newaxis]
        Inorm = np.multiply(self.maxCRef[:, np.newaxis], C)
        Inorm = 255 * np.exp(-self.HERef @ Inorm)
        Inorm = Inorm.T.reshape(img.shape)
        return np.clip(Inorm, 0, 255).astype(np.uint8)

    @staticmethod
    def _standardize_brightness(I: np.ndarray) -> np.ndarray:
        p = np.percentile(I, 90)
        return np.clip(I * 255.0 / p, 0, 255).astype(np.uint8)

    @staticmethod
    def _get_stain_matrix(I: np.ndarray):
        I = I.reshape((-1, 3)).astype(float)
        I = I[np.all(I > 20, axis=1)]
        OD = -np.log((I + 1) / 256)
        eigvals, eigvecs = np.linalg.eigh(np.cov(OD.T))
        eigvecs = eigvecs[:, np.argsort(eigvals)[::-1]]
        V = eigvecs[:, :2]
        That = OD @ V
        phi = np.arctan2(That[:, 1], That[:, 0])
        minPhi = np.percentile(phi, 1)
        maxPhi = np.percentile(phi, 99)
        v1 = V @ np.array([np.cos(minPhi), np.sin(minPhi)])
        v2 = V @ np.array([np.cos(maxPhi), np.sin(maxPhi)])
        if v1[0] > v2[0]:
            HE = np.array([v1, v2]).T
        else:
            HE = np.array([v2, v1]).T
        return HE, V

    @staticmethod
    def _get_concentrations(I: np.ndarray, HE: np.ndarray):
        OD = -np.log((I.reshape((-1, 3)).astype(float) + 1) / 256)
        C, _, _, _ = np.linalg.lstsq(HE, OD.T, rcond=None)
        maxC = np.percentile(C, 99, axis=1)
        return maxC, C

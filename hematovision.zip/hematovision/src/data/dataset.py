"""
HematoVision Dataset
Handles loading, splitting, and serving blood cell images.
"""

import os
import random
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from torchvision import transforms

from src.utils.config import Config, DataConfig


CLASS_TO_IDX = {
    "EOSINOPHIL": 0,
    "LYMPHOCYTE": 1,
    "MONOCYTE": 2,
    "NEUTROPHIL": 3,
}

IDX_TO_CLASS = {v: k for k, v in CLASS_TO_IDX.items()}

LABEL_NAMES = ["Eosinophil", "Lymphocyte", "Monocyte", "Neutrophil"]


class BloodCellDataset(Dataset):
    """
    Dataset for blood cell classification.

    Expects folder structure:
        root/
          EOSINOPHIL/*.jpg
          LYMPHOCYTE/*.jpg
          MONOCYTE/*.jpg
          NEUTROPHIL/*.jpg
    """

    def __init__(
        self,
        root: str,
        transform: Optional[Callable] = None,
        classes: Optional[List[str]] = None,
    ):
        self.root = Path(root)
        self.transform = transform
        self.classes = classes or list(CLASS_TO_IDX.keys())
        self.samples: List[Tuple[str, int]] = []
        self.class_counts: Dict[int, int] = {i: 0 for i in range(len(self.classes))}

        for cls in self.classes:
            cls_dir = self.root / cls
            if not cls_dir.exists():
                # Try lowercase
                cls_dir = self.root / cls.lower()
            if not cls_dir.exists():
                continue
            idx = CLASS_TO_IDX[cls]
            paths = list(cls_dir.glob("*.jpg")) + list(cls_dir.glob("*.jpeg")) + list(cls_dir.glob("*.png"))
            for p in paths:
                self.samples.append((str(p), idx))
                self.class_counts[idx] += 1

        if not self.samples:
            raise RuntimeError(f"No images found in {root}. Check folder structure.")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        path, label = self.samples[idx]
        image = Image.open(path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label

    def get_class_weights(self) -> torch.Tensor:
        """Inverse frequency weights for balanced sampling."""
        total = len(self.samples)
        weights = []
        for _, label in self.samples:
            count = self.class_counts[label]
            weights.append(total / (len(self.classes) * count))
        return torch.tensor(weights, dtype=torch.float)

    def class_distribution(self) -> Dict[str, int]:
        return {IDX_TO_CLASS[i]: c for i, c in self.class_counts.items()}


def get_transforms(
    image_size: Tuple[int, int] = (224, 224),
    phase: str = "train",
    cfg=None,
) -> transforms.Compose:
    """
    Build augmentation pipeline.

    Args:
        image_size: Target (H, W).
        phase: 'train' | 'val' | 'test'
        cfg: AugConfig (optional)
    """
    mean = [0.485, 0.456, 0.406]   # ImageNet stats
    std = [0.229, 0.224, 0.225]

    if phase == "train":
        return transforms.Compose([
            transforms.Resize((image_size[0] + 32, image_size[1] + 32)),
            transforms.RandomCrop(image_size),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.3),
            transforms.RandomRotation(degrees=30),
            transforms.ColorJitter(
                brightness=0.2,
                contrast=0.2,
                saturation=0.2,
                hue=0.1,
            ),
            transforms.RandomGrayscale(p=0.02),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std),
            transforms.RandomErasing(p=0.1, scale=(0.02, 0.1)),
        ])
    else:
        return transforms.Compose([
            transforms.Resize(image_size),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std),
        ])


def mixup_data(
    x: torch.Tensor,
    y: torch.Tensor,
    alpha: float = 0.4,
    device: str = "cpu",
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]:
    """Apply mixup augmentation to a batch."""
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1.0
    batch_size = x.size(0)
    index = torch.randperm(batch_size).to(device)
    mixed_x = lam * x + (1 - lam) * x[index]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def build_dataloaders(
    cfg: Config,
    train_dir: Optional[str] = None,
    val_dir: Optional[str] = None,
    test_dir: Optional[str] = None,
) -> Dict[str, DataLoader]:
    """
    Build train/val/test DataLoaders.

    If val_dir/test_dir not given, splits train_dir automatically.
    """
    img_size = cfg.data.image_size

    # Build datasets
    datasets = {}
    if train_dir:
        train_ds = BloodCellDataset(
            root=train_dir,
            transform=get_transforms(img_size, "train", cfg.aug),
        )
        # Balanced sampler
        class_weights = train_ds.get_class_weights()
        sampler = WeightedRandomSampler(
            weights=class_weights,
            num_samples=len(class_weights),
            replacement=True,
        )
        datasets["train"] = DataLoader(
            train_ds,
            batch_size=cfg.training.batch_size,
            sampler=sampler,
            num_workers=cfg.data.num_workers,
            pin_memory=cfg.data.pin_memory,
            drop_last=True,
        )

    if val_dir:
        val_ds = BloodCellDataset(
            root=val_dir,
            transform=get_transforms(img_size, "val"),
        )
        datasets["val"] = DataLoader(
            val_ds,
            batch_size=cfg.training.batch_size * 2,
            shuffle=False,
            num_workers=cfg.data.num_workers,
            pin_memory=cfg.data.pin_memory,
        )

    if test_dir:
        test_ds = BloodCellDataset(
            root=test_dir,
            transform=get_transforms(img_size, "test"),
        )
        datasets["test"] = DataLoader(
            test_ds,
            batch_size=cfg.training.batch_size * 2,
            shuffle=False,
            num_workers=cfg.data.num_workers,
            pin_memory=cfg.data.pin_memory,
        )

    return datasets

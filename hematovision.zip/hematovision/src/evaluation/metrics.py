"""
HematoVision Evaluation Metrics
Classification report, confusion matrix, per-class metrics, ROC-AUC.
"""

import os
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)

from src.data.dataset import LABEL_NAMES


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: DataLoader,
    device: str = "cpu",
    return_probs: bool = False,
) -> Dict:
    """
    Run full evaluation on a DataLoader.

    Returns dict with:
        - accuracy, precision, recall, f1 (macro)
        - per_class: {class_name: {precision, recall, f1, support}}
        - confusion_matrix
        - roc_auc (macro OvR)
        - all_preds, all_labels, all_probs
    """
    model.eval()
    model.to(device)

    all_preds, all_labels, all_probs = [], [], []

    for images, labels in loader:
        images = images.to(device, non_blocking=True)
        outputs = model(images)
        probs = torch.softmax(outputs, dim=1).cpu().numpy()
        preds = outputs.argmax(dim=1).cpu().numpy()

        all_probs.append(probs)
        all_preds.extend(preds.tolist())
        all_labels.extend(labels.numpy().tolist())

    all_probs = np.vstack(all_probs)
    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)

    # Overall metrics
    acc = accuracy_score(all_labels, all_preds)
    macro_f1 = f1_score(all_labels, all_preds, average="macro")
    macro_prec = precision_score(all_labels, all_preds, average="macro")
    macro_rec = recall_score(all_labels, all_preds, average="macro")

    # ROC-AUC (one-vs-rest)
    try:
        roc_auc = roc_auc_score(all_labels, all_probs, multi_class="ovr", average="macro")
    except Exception:
        roc_auc = None

    # Per-class metrics
    report = classification_report(
        all_labels, all_preds,
        target_names=LABEL_NAMES,
        output_dict=True,
    )
    per_class = {
        name: {
            "precision": report[name]["precision"],
            "recall": report[name]["recall"],
            "f1": report[name]["f1-score"],
            "support": report[name]["support"],
        }
        for name in LABEL_NAMES
    }

    cm = confusion_matrix(all_labels, all_preds)

    result = {
        "accuracy": acc,
        "precision": macro_prec,
        "recall": macro_rec,
        "f1": macro_f1,
        "roc_auc": roc_auc,
        "per_class": per_class,
        "confusion_matrix": cm,
        "all_preds": all_preds,
        "all_labels": all_labels,
    }
    if return_probs:
        result["all_probs"] = all_probs

    return result


def print_evaluation_report(results: Dict) -> None:
    """Pretty-print evaluation results."""
    try:
        from rich.console import Console
        from rich.table import Table
        console = Console()

        # Summary table
        t = Table(title="[bold]HematoVision Evaluation Results[/bold]", show_header=True)
        t.add_column("Metric", style="cyan")
        t.add_column("Value", style="bold green")
        t.add_row("Accuracy", f"{results['accuracy']:.4f} ({results['accuracy']*100:.2f}%)")
        t.add_row("Macro Precision", f"{results['precision']:.4f}")
        t.add_row("Macro Recall", f"{results['recall']:.4f}")
        t.add_row("Macro F1", f"{results['f1']:.4f}")
        if results["roc_auc"]:
            t.add_row("ROC-AUC (macro OvR)", f"{results['roc_auc']:.4f}")
        console.print(t)

        # Per-class table
        t2 = Table(title="[bold]Per-Class Results[/bold]", show_header=True)
        t2.add_column("Class", style="cyan")
        t2.add_column("Precision")
        t2.add_column("Recall")
        t2.add_column("F1")
        t2.add_column("Support")
        for cls, m in results["per_class"].items():
            t2.add_row(
                cls,
                f"{m['precision']:.4f}",
                f"{m['recall']:.4f}",
                f"{m['f1']:.4f}",
                str(int(m['support'])),
            )
        console.print(t2)

    except ImportError:
        print(f"Accuracy: {results['accuracy']:.4f}")
        print(f"F1: {results['f1']:.4f}")


def compute_class_accuracy(results: Dict) -> Dict[str, float]:
    """Per-class accuracy from confusion matrix."""
    cm = results["confusion_matrix"]
    per_class_acc = cm.diagonal() / cm.sum(axis=1)
    return {LABEL_NAMES[i]: float(per_class_acc[i]) for i in range(len(LABEL_NAMES))}

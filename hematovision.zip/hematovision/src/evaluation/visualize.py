"""
HematoVision Visualization
- Confusion matrix heatmap
- Training history curves
- Grad-CAM saliency maps
- t-SNE feature embedding
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from typing import Dict, List, Optional, Tuple

from src.data.dataset import LABEL_NAMES


PALETTE = {
    "eosinophil": "#E24B4A",
    "lymphocyte": "#534AB7",
    "monocyte": "#BA7517",
    "neutrophil": "#1D9E75",
}
CLASS_COLORS = list(PALETTE.values())


def plot_confusion_matrix(
    cm: np.ndarray,
    save_path: Optional[str] = None,
    normalize: bool = True,
    title: str = "Confusion Matrix",
) -> plt.Figure:
    """Plot normalized confusion matrix."""
    if normalize:
        cm_plot = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    else:
        cm_plot = cm

    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(
        cm_plot,
        annot=True,
        fmt=".2f" if normalize else "d",
        cmap="RdYlGn",
        xticklabels=LABEL_NAMES,
        yticklabels=LABEL_NAMES,
        linewidths=0.5,
        linecolor="white",
        cbar_kws={"shrink": 0.8},
        ax=ax,
    )
    ax.set_xlabel("Predicted", fontsize=12, labelpad=10)
    ax.set_ylabel("True", fontsize=12, labelpad=10)
    ax.set_title(title, fontsize=14, fontweight="bold", pad=15)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_training_history(
    history: Dict[str, List[float]],
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Plot training/validation loss and accuracy curves."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    epochs = range(1, len(history["train_loss"]) + 1)

    # Loss
    ax = axes[0]
    ax.plot(epochs, history["train_loss"], label="Train", color="#E24B4A", linewidth=2)
    ax.plot(epochs, history["val_loss"], label="Val", color="#534AB7", linewidth=2, linestyle="--")
    ax.set_title("Loss", fontweight="bold")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.legend()
    ax.grid(alpha=0.3)

    # Accuracy
    ax = axes[1]
    ax.plot(epochs, [v * 100 for v in history["train_acc"]], label="Train", color="#E24B4A", linewidth=2)
    ax.plot(epochs, [v * 100 for v in history["val_acc"]], label="Val", color="#534AB7", linewidth=2, linestyle="--")
    ax.set_title("Accuracy", fontweight="bold")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Accuracy (%)")
    ax.legend()
    ax.grid(alpha=0.3)
    ax.set_ylim([50, 101])

    # Learning rate
    ax = axes[2]
    ax.plot(epochs, history["lr"], color="#1D9E75", linewidth=2)
    ax.set_title("Learning Rate", fontweight="bold")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("LR")
    ax.set_yscale("log")
    ax.grid(alpha=0.3)

    fig.suptitle("HematoVision Training History", fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_per_class_metrics(
    per_class: Dict[str, Dict[str, float]],
    save_path: Optional[str] = None,
) -> plt.Figure:
    """Bar chart of per-class precision, recall, F1."""
    classes = list(per_class.keys())
    metrics = ["precision", "recall", "f1"]
    x = np.arange(len(classes))
    width = 0.25

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = ["#E24B4A", "#534AB7", "#1D9E75"]
    labels = ["Precision", "Recall", "F1"]

    for i, (metric, color, label) in enumerate(zip(metrics, colors, labels)):
        values = [per_class[c][metric] for c in classes]
        bars = ax.bar(x + i * width, values, width, label=label, color=color, alpha=0.85)
        for bar in bars:
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{bar.get_height():.2f}",
                ha="center", va="bottom", fontsize=8,
            )

    ax.set_xticks(x + width)
    ax.set_xticklabels(classes)
    ax.set_ylim([0.7, 1.05])
    ax.set_ylabel("Score")
    ax.set_title("Per-Class Classification Metrics", fontweight="bold", fontsize=13)
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def visualize_gradcam(
    model,
    image_tensor,
    target_layer_name: str = "backbone.blocks",
    class_idx: Optional[int] = None,
    save_path: Optional[str] = None,
):
    """
    Generate Grad-CAM visualization for a single image.
    Requires grad-cam package: pip install grad-cam
    """
    try:
        from pytorch_grad_cam import GradCAM
        from pytorch_grad_cam.utils.image import show_cam_on_image
    except ImportError:
        print("Install grad-cam: pip install grad-cam")
        return None

    import torch
    model.eval()

    # Find target layer
    target_layers = []
    for name, module in model.named_modules():
        if target_layer_name in name and hasattr(module, "weight"):
            target_layers = [module]
            break

    if not target_layers:
        # Fallback: last conv layer
        for name, module in model.named_modules():
            if isinstance(module, torch.nn.Conv2d):
                target_layers = [module]

    cam = GradCAM(model=model, target_layers=target_layers)
    grayscale_cam = cam(input_tensor=image_tensor.unsqueeze(0), targets=None)

    # Denormalize image for display
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    img_np = image_tensor.permute(1, 2, 0).numpy()
    img_np = np.clip(std * img_np + mean, 0, 1)

    cam_image = show_cam_on_image(img_np, grayscale_cam[0], use_rgb=True)

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    axes[0].imshow(img_np)
    axes[0].set_title("Original Image", fontweight="bold")
    axes[0].axis("off")
    axes[1].imshow(cam_image)
    axes[1].set_title("Grad-CAM", fontweight="bold")
    axes[1].axis("off")
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_tsne(
    features: np.ndarray,
    labels: np.ndarray,
    save_path: Optional[str] = None,
) -> plt.Figure:
    """t-SNE embedding of backbone features colored by class."""
    from sklearn.manifold import TSNE
    tsne = TSNE(n_components=2, perplexity=40, n_iter=1000, random_state=42)
    emb = tsne.fit_transform(features)

    fig, ax = plt.subplots(figsize=(8, 6))
    for i, (name, color) in enumerate(zip(LABEL_NAMES, CLASS_COLORS)):
        mask = labels == i
        ax.scatter(emb[mask, 0], emb[mask, 1], c=color, label=name, alpha=0.6, s=20)

    ax.set_title("t-SNE Feature Embedding", fontweight="bold", fontsize=13)
    ax.legend(loc="upper right")
    ax.axis("off")
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig

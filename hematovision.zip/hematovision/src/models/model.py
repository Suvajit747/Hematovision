"""
HematoVision Model
Transfer learning classifier for blood cell classification.
Supports EfficientNet, ResNet, DenseNet, MobileNet backbones via timm.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple

try:
    import timm
    HAS_TIMM = True
except ImportError:
    HAS_TIMM = False

from torchvision import models


SUPPORTED_BACKBONES = {
    # timm backbones
    "efficientnet_b0": {"timm": True, "features": 1280},
    "efficientnet_b3": {"timm": True, "features": 1536},
    "efficientnet_b4": {"timm": True, "features": 1792},
    "efficientnet_v2_s": {"timm": True, "features": 1280},
    "densenet121": {"timm": True, "features": 1024},
    "densenet169": {"timm": True, "features": 1664},
    "convnext_tiny": {"timm": True, "features": 768},
    "mobilenetv3_large_100": {"timm": True, "features": 960},
    # torchvision backbones
    "resnet50": {"timm": False, "features": 2048},
    "resnet101": {"timm": False, "features": 2048},
}


class AttentionPooling(nn.Module):
    """Soft attention over spatial features before classification head."""

    def __init__(self, in_features: int):
        super().__init__()
        self.attention = nn.Sequential(
            nn.Linear(in_features, in_features // 4),
            nn.Tanh(),
            nn.Linear(in_features // 4, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, N, C)
        weights = self.attention(x)       # (B, N, 1)
        weights = F.softmax(weights, dim=1)
        return (x * weights).sum(dim=1)  # (B, C)


class HematoVisionClassifier(nn.Module):
    """
    Transfer learning classifier for blood cell images.

    Architecture:
        Pre-trained backbone → Global Avg Pool → Dropout → FC(512) → BN → ReLU → Dropout → FC(4)

    Args:
        backbone: Name of pre-trained backbone (see SUPPORTED_BACKBONES).
        num_classes: Number of target classes (default 4).
        pretrained: Whether to load ImageNet weights.
        dropout1: Dropout after backbone.
        dropout2: Dropout in classifier head.
        hidden_dim: Hidden layer dimension.
        freeze_backbone: If True, freezes all backbone parameters.
    """

    def __init__(
        self,
        backbone: str = "efficientnet_b3",
        num_classes: int = 4,
        pretrained: bool = True,
        dropout1: float = 0.3,
        dropout2: float = 0.2,
        hidden_dim: int = 512,
        freeze_backbone: bool = False,
    ):
        super().__init__()
        self.backbone_name = backbone
        self.num_classes = num_classes

        # ── Build backbone ────────────────────────────────────────────────────
        if backbone in SUPPORTED_BACKBONES and SUPPORTED_BACKBONES[backbone]["timm"]:
            if not HAS_TIMM:
                raise ImportError("timm is required: pip install timm")
            self.backbone = timm.create_model(
                backbone,
                pretrained=pretrained,
                num_classes=0,              # Remove classifier head
                global_pool="avg",
            )
            in_features = self.backbone.num_features
        elif backbone == "resnet50":
            weights = models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
            base = models.resnet50(weights=weights)
            self.backbone = nn.Sequential(*list(base.children())[:-2])
            in_features = 2048
        elif backbone == "resnet101":
            weights = models.ResNet101_Weights.IMAGENET1K_V2 if pretrained else None
            base = models.resnet101(weights=weights)
            self.backbone = nn.Sequential(*list(base.children())[:-2])
            in_features = 2048
        else:
            raise ValueError(f"Unsupported backbone: {backbone}. Choose from {list(SUPPORTED_BACKBONES.keys())}")

        # ── Freeze backbone ───────────────────────────────────────────────────
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False

        # ── Pooling ───────────────────────────────────────────────────────────
        # timm models already pool; torchvision ResNets need pooling
        self._needs_pool = backbone.startswith("resnet")
        if self._needs_pool:
            self.pool = nn.AdaptiveAvgPool2d(1)

        # ── Classifier head ───────────────────────────────────────────────────
        self.classifier = nn.Sequential(
            nn.Dropout(p=dropout1),
            nn.Linear(in_features, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout2),
            nn.Linear(hidden_dim, num_classes),
        )

        # Initialize head weights
        self._init_head()

    def _init_head(self):
        for m in self.classifier.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        if self._needs_pool:
            features = self.pool(features).flatten(1)
        return self.classifier(features)

    def get_features(self, x: torch.Tensor) -> torch.Tensor:
        """Return backbone features (for visualization / Grad-CAM)."""
        return self.backbone(x)

    def unfreeze_backbone(self, num_layers: Optional[int] = None):
        """
        Progressively unfreeze backbone layers for fine-tuning.
        If num_layers is None, unfreezes all.
        """
        params = list(self.backbone.parameters())
        if num_layers is None:
            for p in params:
                p.requires_grad = True
        else:
            for p in params[-num_layers:]:
                p.requires_grad = True

    def count_parameters(self) -> Dict[str, int]:
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {"total": total, "trainable": trainable, "frozen": total - trainable}

    @classmethod
    def from_checkpoint(cls, path: str, device: str = "cpu") -> "HematoVisionClassifier":
        """Load a saved model from checkpoint."""
        ckpt = torch.load(path, map_location=device)
        cfg = ckpt["model_config"]
        model = cls(**cfg)
        model.load_state_dict(ckpt["model_state_dict"])
        model.eval()
        return model

    def save_checkpoint(
        self,
        path: str,
        epoch: int,
        optimizer_state: Optional[dict] = None,
        metrics: Optional[dict] = None,
    ):
        """Save model + training state."""
        import os
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            "epoch": epoch,
            "model_state_dict": self.state_dict(),
            "optimizer_state_dict": optimizer_state,
            "metrics": metrics,
            "model_config": {
                "backbone": self.backbone_name,
                "num_classes": self.num_classes,
                "pretrained": False,
            },
        }, path)


def build_model(cfg) -> HematoVisionClassifier:
    """Build model from ModelConfig."""
    return HematoVisionClassifier(
        backbone=cfg.model.backbone,
        num_classes=cfg.model.num_classes,
        pretrained=cfg.model.pretrained,
        dropout1=cfg.model.dropout1,
        dropout2=cfg.model.dropout2,
        hidden_dim=cfg.model.hidden_dim,
        freeze_backbone=cfg.model.freeze_backbone,
    )

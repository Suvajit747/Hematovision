"""
HematoVision Loss Functions
Focal Loss, Label Smoothing CrossEntropy, and Mixup loss.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance in blood cell datasets.

    FL(pt) = -alpha_t * (1 - pt)^gamma * log(pt)

    Args:
        gamma: Focusing parameter. Higher = more focus on hard examples. (default 2)
        alpha: Class weights tensor or scalar. (default None = uniform)
        reduction: 'mean' | 'sum' | 'none'
    """

    def __init__(
        self,
        gamma: float = 2.0,
        alpha: Optional[torch.Tensor] = None,
        reduction: str = "mean",
    ):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        ce_loss = F.cross_entropy(inputs, targets, weight=self.alpha, reduction="none")
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss

        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        return focal_loss


class LabelSmoothingCrossEntropy(nn.Module):
    """
    Cross-entropy with label smoothing for regularization.

    Args:
        smoothing: Smoothing factor in [0, 1). (default 0.1)
    """

    def __init__(self, smoothing: float = 0.1):
        super().__init__()
        self.smoothing = smoothing

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        n_classes = inputs.size(-1)
        log_probs = F.log_softmax(inputs, dim=-1)

        # One-hot encode
        with torch.no_grad():
            smooth_targets = torch.zeros_like(log_probs)
            smooth_targets.fill_(self.smoothing / (n_classes - 1))
            smooth_targets.scatter_(1, targets.unsqueeze(1), 1.0 - self.smoothing)

        return -(smooth_targets * log_probs).sum(dim=-1).mean()


class MixupLoss(nn.Module):
    """
    Mixup-compatible loss: combines two target labels weighted by lambda.
    Use with mixup_data() in dataset.py.
    """

    def __init__(self, base_loss: nn.Module):
        super().__init__()
        self.base_loss = base_loss

    def forward(
        self,
        inputs: torch.Tensor,
        targets_a: torch.Tensor,
        targets_b: torch.Tensor,
        lam: float,
    ) -> torch.Tensor:
        return lam * self.base_loss(inputs, targets_a) + (1 - lam) * self.base_loss(inputs, targets_b)


def build_loss(cfg) -> nn.Module:
    """Build loss function from TrainingConfig."""
    loss_fn = cfg.training.loss_fn.lower()

    if loss_fn == "focal":
        return FocalLoss(gamma=cfg.training.focal_gamma)
    elif loss_fn == "crossentropy":
        return nn.CrossEntropyLoss()
    elif loss_fn == "label_smooth":
        return LabelSmoothingCrossEntropy(smoothing=cfg.training.label_smoothing)
    else:
        raise ValueError(f"Unknown loss function: {loss_fn}")

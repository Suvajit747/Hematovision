"""
HematoVision Trainer
Full training loop with:
  - Mixed precision (AMP)
  - Cosine LR scheduling with warmup
  - Early stopping
  - Mixup augmentation
  - TensorBoard logging
  - Checkpoint saving (best + periodic)
"""

import os
import time
import math
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler, autocast

try:
    from torch.utils.tensorboard import SummaryWriter
    HAS_TB = True
except ImportError:
    HAS_TB = False

from tqdm import tqdm

from src.data.dataset import mixup_data
from src.training.losses import build_loss, MixupLoss
from src.utils.config import Config
from src.utils.logger import get_logger, print_metrics


class EarlyStopper:
    def __init__(self, patience: int = 7, min_delta: float = 1e-4):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_score: Optional[float] = None
        self.should_stop = False

    def step(self, score: float) -> bool:
        if self.best_score is None or score > self.best_score + self.min_delta:
            self.best_score = score
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
        return self.should_stop


class HematoTrainer:
    """
    Orchestrates the full training lifecycle for HematoVision.

    Usage:
        trainer = HematoTrainer(model, dataloaders, cfg)
        history = trainer.train()
    """

    def __init__(
        self,
        model: nn.Module,
        dataloaders: Dict[str, DataLoader],
        cfg: Config,
        device: Optional[str] = None,
    ):
        self.model = model
        self.dataloaders = dataloaders
        self.cfg = cfg
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.logger = get_logger("trainer", cfg.log_dir)

        self.model.to(self.device)

        # ── Optimizer ─────────────────────────────────────────────────────────
        self.optimizer = AdamW(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=cfg.training.learning_rate,
            weight_decay=cfg.training.weight_decay,
        )

        # ── Scheduler (warmup + cosine) ───────────────────────────────────────
        warmup = LinearLR(
            self.optimizer,
            start_factor=0.1,
            end_factor=1.0,
            total_iters=cfg.training.warmup_epochs,
        )
        cosine = CosineAnnealingLR(
            self.optimizer,
            T_max=cfg.training.epochs - cfg.training.warmup_epochs,
            eta_min=cfg.training.min_lr,
        )
        self.scheduler = SequentialLR(
            self.optimizer,
            schedulers=[warmup, cosine],
            milestones=[cfg.training.warmup_epochs],
        )

        # ── Loss ──────────────────────────────────────────────────────────────
        base_loss = build_loss(cfg)
        self.loss_fn = base_loss
        self.mixup_loss = MixupLoss(base_loss)

        # ── AMP Scaler ────────────────────────────────────────────────────────
        self.scaler = GradScaler(enabled=cfg.training.use_amp and self.device != "cpu")

        # ── Bookkeeping ───────────────────────────────────────────────────────
        self.early_stopper = EarlyStopper(patience=cfg.training.early_stop_patience)
        self.best_val_acc = 0.0
        self.history: Dict[str, List[float]] = {
            "train_loss": [], "val_loss": [],
            "train_acc": [], "val_acc": [],
            "lr": [],
        }

        # ── TensorBoard ───────────────────────────────────────────────────────
        self.writer = None
        if HAS_TB:
            tb_dir = os.path.join(cfg.log_dir, cfg.experiment_name)
            self.writer = SummaryWriter(tb_dir)
            self.logger.info(f"TensorBoard logs → {tb_dir}")

        os.makedirs(cfg.training.checkpoint_dir, exist_ok=True)

    # ── Training epoch ─────────────────────────────────────────────────────────

    def _train_epoch(self, epoch: int) -> Tuple[float, float]:
        self.model.train()
        loader = self.dataloaders["train"]
        total_loss = correct = total = 0

        use_mixup = self.cfg.aug.use_mixup
        alpha = self.cfg.aug.mixup_alpha

        pbar = tqdm(loader, desc=f"Train {epoch}", leave=False, ncols=100)
        for images, labels in pbar:
            images = images.to(self.device, non_blocking=True)
            labels = labels.to(self.device, non_blocking=True)

            # Mixup
            if use_mixup and torch.rand(1).item() < 0.5:
                images, labels_a, labels_b, lam = mixup_data(images, labels, alpha, self.device)
                with autocast(enabled=self.scaler.is_enabled()):
                    outputs = self.model(images)
                    loss = self.mixup_loss(outputs, labels_a, labels_b, lam)
            else:
                with autocast(enabled=self.scaler.is_enabled()):
                    outputs = self.model(images)
                    loss = self.loss_fn(outputs, labels)

            self.optimizer.zero_grad(set_to_none=True)
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(), self.cfg.training.gradient_clip
            )
            self.scaler.step(self.optimizer)
            self.scaler.update()

            total_loss += loss.item() * images.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += images.size(0)

            pbar.set_postfix(loss=f"{loss.item():.3f}", acc=f"{correct/total:.3f}")

        return total_loss / total, correct / total

    # ── Validation epoch ───────────────────────────────────────────────────────

    @torch.no_grad()
    def _val_epoch(self) -> Tuple[float, float]:
        self.model.eval()
        loader = self.dataloaders["val"]
        total_loss = correct = total = 0

        for images, labels in loader:
            images = images.to(self.device, non_blocking=True)
            labels = labels.to(self.device, non_blocking=True)

            with autocast(enabled=self.scaler.is_enabled()):
                outputs = self.model(images)
                loss = self.loss_fn(outputs, labels)

            total_loss += loss.item() * images.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += images.size(0)

        return total_loss / total, correct / total

    # ── Main train loop ────────────────────────────────────────────────────────

    def train(self) -> Dict[str, List[float]]:
        cfg = self.cfg.training
        self.logger.info(f"Training on {self.device} | Epochs: {cfg.epochs} | BS: {cfg.batch_size}")

        for epoch in range(1, cfg.epochs + 1):
            t0 = time.time()

            train_loss, train_acc = self._train_epoch(epoch)
            val_loss, val_acc = self._val_epoch()
            self.scheduler.step()

            lr = self.optimizer.param_groups[0]["lr"]
            elapsed = time.time() - t0

            # Log
            self.history["train_loss"].append(train_loss)
            self.history["val_loss"].append(val_loss)
            self.history["train_acc"].append(train_acc)
            self.history["val_acc"].append(val_acc)
            self.history["lr"].append(lr)

            if self.writer:
                self.writer.add_scalars("Loss", {"train": train_loss, "val": val_loss}, epoch)
                self.writer.add_scalars("Accuracy", {"train": train_acc, "val": val_acc}, epoch)
                self.writer.add_scalar("LR", lr, epoch)

            metrics = {
                "Train Loss": train_loss, "Val Loss": val_loss,
                "Train Acc": train_acc, "Val Acc": val_acc,
                "LR": lr, "Time(s)": elapsed,
            }
            print_metrics(metrics, epoch)

            # Best model
            if val_acc > self.best_val_acc:
                self.best_val_acc = val_acc
                best_path = os.path.join(cfg.checkpoint_dir, "best_model.pth")
                self.model.save_checkpoint(
                    best_path, epoch,
                    self.optimizer.state_dict(),
                    {"val_acc": val_acc, "val_loss": val_loss},
                )
                self.logger.info(f"[green]✓ New best model saved (val_acc={val_acc:.4f})[/green]")

            # Periodic checkpoint
            if epoch % cfg.save_every == 0:
                ckpt_path = os.path.join(cfg.checkpoint_dir, f"epoch_{epoch:03d}.pth")
                self.model.save_checkpoint(ckpt_path, epoch, self.optimizer.state_dict())

            # Early stopping
            if self.early_stopper.step(val_acc):
                self.logger.info(f"Early stopping at epoch {epoch} (patience={cfg.early_stop_patience})")
                break

        if self.writer:
            self.writer.close()

        self.logger.info(f"Training complete. Best val accuracy: {self.best_val_acc:.4f}")
        return self.history

"""
HematoVision Configuration
Central hyperparameter and path management.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import yaml


@dataclass
class DataConfig:
    data_dir: str = "data/raw"
    processed_dir: str = "data/processed"
    image_size: Tuple[int, int] = (224, 224)
    num_workers: int = 4
    pin_memory: bool = True
    classes: List[str] = field(default_factory=lambda: [
        "EOSINOPHIL", "LYMPHOCYTE", "MONOCYTE", "NEUTROPHIL"
    ])
    class_labels: List[str] = field(default_factory=lambda: [
        "Eosinophil", "Lymphocyte", "Monocyte", "Neutrophil"
    ])
    train_split: float = 0.8
    val_split: float = 0.1
    test_split: float = 0.1


@dataclass
class AugConfig:
    # Basic augmentations
    random_horizontal_flip: float = 0.5
    random_vertical_flip: float = 0.3
    random_rotation: int = 30
    # Color augmentations
    brightness: float = 0.2
    contrast: float = 0.2
    saturation: float = 0.2
    hue: float = 0.1
    # Advanced
    use_mixup: bool = True
    mixup_alpha: float = 0.4
    use_cutmix: bool = False
    cutmix_alpha: float = 1.0
    # Stain normalization (Macenko method)
    use_stain_norm: bool = False


@dataclass
class ModelConfig:
    backbone: str = "efficientnet_b3"       # efficientnet_b3 | resnet50 | densenet121 | mobilenetv3_large
    pretrained: bool = True
    freeze_backbone: bool = False            # Fine-tune full network
    freeze_until_layer: Optional[str] = None
    dropout1: float = 0.3
    dropout2: float = 0.2
    hidden_dim: int = 512
    num_classes: int = 4


@dataclass
class TrainingConfig:
    # Core
    epochs: int = 30
    batch_size: int = 32
    learning_rate: float = 1e-4
    weight_decay: float = 1e-4
    # Scheduler
    scheduler: str = "cosine"               # cosine | step | plateau
    warmup_epochs: int = 3
    min_lr: float = 1e-7
    # Loss
    loss_fn: str = "focal"                  # focal | crossentropy | label_smooth
    focal_gamma: float = 2.0
    label_smoothing: float = 0.1
    # Regularization
    gradient_clip: float = 1.0
    # Checkpointing
    checkpoint_dir: str = "models/checkpoints"
    save_every: int = 5
    early_stop_patience: int = 7
    # Mixed precision
    use_amp: bool = True
    # Reproducibility
    seed: int = 42


@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    aug: AugConfig = field(default_factory=AugConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    # Paths
    results_dir: str = "results"
    log_dir: str = "runs"
    experiment_name: str = "hematovision_run"

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        import dataclasses
        with open(path, "w") as f:
            yaml.dump(dataclasses.asdict(self), f, default_flow_style=False)

    @classmethod
    def load(cls, path: str) -> "Config":
        with open(path) as f:
            d = yaml.safe_load(f)
        cfg = cls()
        cfg.data = DataConfig(**d.get("data", {}))
        cfg.aug = AugConfig(**d.get("aug", {}))
        cfg.model = ModelConfig(**d.get("model", {}))
        cfg.training = TrainingConfig(**d.get("training", {}))
        return cfg


DEFAULT_CONFIG = Config()

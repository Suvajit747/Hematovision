"""
HematoVision Logger
Rich console + file logging with TensorBoard support.
"""

import logging
import os
from datetime import datetime
from typing import Dict, Optional

from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint


console = Console()


def get_logger(name: str, log_dir: Optional[str] = None) -> logging.Logger:
    """Create a rich-formatted logger with optional file output."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if logger.handlers:
        return logger

    # Rich console handler
    rich_handler = RichHandler(
        console=console,
        rich_tracebacks=True,
        markup=True,
        show_path=False,
    )
    rich_handler.setLevel(logging.INFO)
    logger.addHandler(rich_handler)

    # File handler
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fh = logging.FileHandler(os.path.join(log_dir, f"{name}_{ts}.log"))
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(fh)

    return logger


def print_config(cfg) -> None:
    """Pretty-print config using rich."""
    import dataclasses
    d = dataclasses.asdict(cfg)
    for section, values in d.items():
        if isinstance(values, dict):
            t = Table(title=f"[bold]{section.upper()}[/bold]", show_header=False, box=None, padding=(0, 2))
            t.add_column("Key", style="dim")
            t.add_column("Value", style="green")
            for k, v in values.items():
                t.add_row(k, str(v))
            console.print(t)


def print_metrics(metrics: Dict[str, float], epoch: int, phase: str = "Val") -> None:
    """Print epoch metrics in a formatted table."""
    t = Table(title=f"[bold]{phase} — Epoch {epoch}[/bold]", show_header=True)
    t.add_column("Metric", style="cyan")
    t.add_column("Value", style="bold green")
    for k, v in metrics.items():
        t.add_row(k, f"{v:.4f}" if isinstance(v, float) else str(v))
    console.print(t)


def print_banner() -> None:
    console.print(Panel.fit(
        "[bold red]Hemato[/bold red][bold white]Vision[/bold white]\n"
        "[dim]Advanced Blood Cell Classification · Transfer Learning[/dim]",
        border_style="red",
        padding=(1, 4),
    ))

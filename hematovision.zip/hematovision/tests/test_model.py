"""
HematoVision Unit Tests
Tests for model, losses, dataset utilities, and inference pipeline.
"""

import pytest
import torch
import numpy as np
from PIL import Image
import io


# ─── Model Tests ──────────────────────────────────────────────────────────────

class TestHematoVisionModel:
    """Test the model forward pass, output shapes, and checkpoint I/O."""

    @pytest.fixture(autouse=True)
    def setup(self):
        from src.models.model import HematoVisionClassifier
        # Use a tiny backbone mock — skip real pretrained download in CI
        self.num_classes = 4
        self.batch_size = 2

    def test_model_output_shape(self):
        """Model should output (B, num_classes) logits."""
        from src.models.model import HematoVisionClassifier
        try:
            model = HematoVisionClassifier(
                backbone="efficientnet_b0",
                num_classes=self.num_classes,
                pretrained=False,
            )
        except Exception:
            pytest.skip("timm not installed")

        x = torch.randn(self.batch_size, 3, 224, 224)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (self.batch_size, self.num_classes)

    def test_model_count_parameters(self):
        """Parameter count should be > 0 and trainable <= total."""
        from src.models.model import HematoVisionClassifier
        try:
            model = HematoVisionClassifier(backbone="efficientnet_b0", pretrained=False)
        except Exception:
            pytest.skip("timm not installed")

        counts = model.count_parameters()
        assert counts["total"] > 0
        assert counts["trainable"] <= counts["total"]
        assert counts["frozen"] >= 0

    def test_freeze_backbone(self):
        """Freezing backbone should set requires_grad=False for backbone params."""
        from src.models.model import HematoVisionClassifier
        try:
            model = HematoVisionClassifier(backbone="efficientnet_b0", pretrained=False, freeze_backbone=True)
        except Exception:
            pytest.skip("timm not installed")

        for name, param in model.backbone.named_parameters():
            assert not param.requires_grad, f"Backbone param {name} should be frozen"

    def test_classifier_head_trainable_when_frozen(self):
        """Classifier head should remain trainable even when backbone is frozen."""
        from src.models.model import HematoVisionClassifier
        try:
            model = HematoVisionClassifier(backbone="efficientnet_b0", pretrained=False, freeze_backbone=True)
        except Exception:
            pytest.skip("timm not installed")

        for name, param in model.classifier.named_parameters():
            assert param.requires_grad, f"Classifier param {name} should be trainable"

    def test_resnet50_output_shape(self):
        """ResNet50 backbone should also produce correct output shape."""
        from src.models.model import HematoVisionClassifier
        try:
            model = HematoVisionClassifier(backbone="resnet50", pretrained=False)
        except Exception:
            pytest.skip("torchvision not installed")

        x = torch.randn(2, 3, 224, 224)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 4)


# ─── Loss Function Tests ───────────────────────────────────────────────────────

class TestLossFunctions:

    def test_focal_loss_output_shape(self):
        from src.training.losses import FocalLoss
        loss_fn = FocalLoss(gamma=2.0)
        logits = torch.randn(8, 4)
        labels = torch.randint(0, 4, (8,))
        loss = loss_fn(logits, labels)
        assert loss.shape == torch.Size([])   # scalar
        assert not torch.isnan(loss)
        assert loss.item() >= 0

    def test_focal_loss_vs_crossentropy(self):
        """When gamma=0, focal loss ≈ cross-entropy."""
        from src.training.losses import FocalLoss
        import torch.nn as nn

        focal = FocalLoss(gamma=0.0)
        ce = nn.CrossEntropyLoss()

        torch.manual_seed(0)
        logits = torch.randn(16, 4)
        labels = torch.randint(0, 4, (16,))

        fl = focal(logits, labels).item()
        cel = ce(logits, labels).item()
        assert abs(fl - cel) < 1e-4, f"FL({fl:.6f}) ≠ CE({cel:.6f}) with gamma=0"

    def test_label_smoothing_loss(self):
        from src.training.losses import LabelSmoothingCrossEntropy
        loss_fn = LabelSmoothingCrossEntropy(smoothing=0.1)
        logits = torch.randn(8, 4)
        labels = torch.randint(0, 4, (8,))
        loss = loss_fn(logits, labels)
        assert loss.shape == torch.Size([])
        assert not torch.isnan(loss)

    def test_mixup_loss(self):
        from src.training.losses import FocalLoss, MixupLoss
        base = FocalLoss()
        mixup = MixupLoss(base)
        logits = torch.randn(8, 4)
        labels_a = torch.randint(0, 4, (8,))
        labels_b = torch.randint(0, 4, (8,))
        loss = mixup(logits, labels_a, labels_b, lam=0.6)
        assert not torch.isnan(loss)


# ─── Dataset Tests ─────────────────────────────────────────────────────────────

class TestDataset:

    def test_transforms_output_shape(self):
        """Train transforms should produce (3, 224, 224) tensors."""
        from src.data.dataset import get_transforms
        transform = get_transforms(image_size=(224, 224), phase="train")

        img = Image.new("RGB", (320, 320), color=(128, 64, 200))
        tensor = transform(img)

        assert tensor.shape == (3, 224, 224)
        assert tensor.dtype == torch.float32

    def test_val_transforms_deterministic(self):
        """Val transforms should produce identical outputs for the same image."""
        from src.data.dataset import get_transforms
        transform = get_transforms(image_size=(224, 224), phase="val")

        img = Image.new("RGB", (300, 300), color=(100, 150, 200))
        t1 = transform(img)
        t2 = transform(img)
        assert torch.allclose(t1, t2)

    def test_mixup_data(self):
        """Mixup should return correct shapes and lambda in [0, 1]."""
        from src.data.dataset import mixup_data
        x = torch.randn(8, 3, 224, 224)
        y = torch.randint(0, 4, (8,))
        mixed_x, y_a, y_b, lam = mixup_data(x, y, alpha=0.4)

        assert mixed_x.shape == x.shape
        assert y_a.shape == y.shape
        assert y_b.shape == y.shape
        assert 0.0 <= lam <= 1.0

    def test_class_to_idx_mapping(self):
        """CLASS_TO_IDX and IDX_TO_CLASS should be consistent."""
        from src.data.dataset import CLASS_TO_IDX, IDX_TO_CLASS
        for cls, idx in CLASS_TO_IDX.items():
            assert IDX_TO_CLASS[idx] == cls


# ─── Config Tests ──────────────────────────────────────────────────────────────

class TestConfig:

    def test_default_config_creation(self):
        from src.utils.config import Config
        cfg = Config()
        assert cfg.model.num_classes == 4
        assert cfg.training.epochs == 30
        assert cfg.training.learning_rate == 1e-4

    def test_config_save_load(self, tmp_path):
        from src.utils.config import Config
        cfg = Config()
        cfg.model.backbone = "resnet50"
        cfg.training.epochs = 50

        save_path = str(tmp_path / "test_config.yaml")
        cfg.save(save_path)

        loaded = Config.load(save_path)
        assert loaded.model.backbone == "resnet50"
        assert loaded.training.epochs == 50


# ─── Prediction Pipeline Test ─────────────────────────────────────────────────

class TestPredictionPipeline:

    def test_softmax_sums_to_one(self):
        """Softmax probabilities from model output should sum to 1."""
        import torch.nn.functional as F
        logits = torch.randn(1, 4)
        probs = F.softmax(logits, dim=1)
        assert abs(probs.sum().item() - 1.0) < 1e-6

    def test_argmax_in_valid_range(self):
        """Predicted class index should be in [0, num_classes-1]."""
        logits = torch.tensor([[0.1, 0.5, 0.2, 0.2]])
        pred = logits.argmax(dim=1).item()
        assert 0 <= pred <= 3


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
